import React from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import PassportSystem from './modules/passport/PassportSystem'
import BankSystem from './modules/bank/BankSystem'
import CultureModule from './modules/culture/CulturePortal'
import ServicesModule from './modules/gov/ServicesModule'
import CitizenCabinet from './modules/cabinet/CitizenCabinet'
import EconomyModule from './modules/economy/EconomyModule'
import MapModule from './modules/map/MapModule'

export default function App(){ 
  return (
    <Router>
      <div className="min-h-screen bg-slate-900 text-slate-100">
        <header className="p-4 bg-slate-800/60 flex gap-3 flex-wrap">
          <Link to="/">Паспорт</Link>
          <Link to="/bank">Банк</Link>
          <Link to="/culture">Культура</Link>
          <Link to="/services">Госуслуги</Link>
          <Link to="/cabinet">Кабинет</Link>
          <Link to="/economy">Экономика</Link>
          <Link to="/map">Карта</Link>
        </header>
        <main className="p-6 max-w-6xl mx-auto">
          <Routes>
            <Route path="/" element={<PassportSystem/>} />
            <Route path="/bank" element={<BankSystem/>} />
            <Route path="/culture" element={<CultureModule/>} />
            <Route path="/services" element={<ServicesModule/>} />
            <Route path="/cabinet" element={<CitizenCabinet/>} />
            <Route path="/economy" element={<EconomyModule/>} />
            <Route path="/map" element={<MapModule/>} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}
