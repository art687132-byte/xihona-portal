import React, { useState } from 'react'

export default function MapModule(){
  const regions = [
    { id:'north', name:'Северный округ', color:'#60a5fa' },
    { id:'central', name:'Центральный округ', color:'#34d399' },
    { id:'south', name:'Южный округ', color:'#f87171' }
  ]
  const [selected, setSelected] = useState(null)

  return (
    <div className="p-4 bg-slate-800 rounded-lg">
      <h2 className="text-2xl font-bold">Карта</h2>
      <svg viewBox="0 0 600 300" className="w-full mt-4 rounded">
        <rect x="0" y="0" width="200" height="300" fill="#0ea5e9" onClick={()=>setSelected(regions[0])} />
        <rect x="200" y="0" width="200" height="300" fill="#10b981" onClick={()=>setSelected(regions[1])} />
        <rect x="400" y="0" width="200" height="300" fill="#fb7185" onClick={()=>setSelected(regions[2])} />
        <text x="100" y="150" fontSize="20" fill="#042a2b">Север</text>
        <text x="300" y="150" fontSize="20" fill="#042a2b">Центр</text>
        <text x="500" y="150" fontSize="20" fill="#042a2b">Юг</text>
      </svg>
      <div className="mt-3 text-slate-300">{selected ? <div>Выбрано: <b>{selected.name}</b></div> : 'Кликните область'}</div>
    </div>
  )
}
