import React, { useState, useRef } from 'react'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'
import { v4 as uuidv4 } from 'uuid'
import useLocalState from '../../utils/useLocalState'

export default function PassportSystem(){
  const [people, setPeople] = useLocalState('x:people', [])
  const [form, setForm] = useState({ familyName: '', givenName: '', dob: '', birthplace: '', passportNumber: '', photo: null })
  const previewRef = useRef(null)

  function handle(e){ setForm({...form, [e.target.name]: e.target.value}) }
  function upload(e){ const f = e.target.files?.[0]; if(!f) return; const r=new FileReader(); r.onload=ev=>setForm(prev=>({...prev, photo:ev.target.result})); r.readAsDataURL(f) }
  function gen(){ setForm(prev=>({...prev, passportNumber:'XH'+Math.floor(100000+Math.random()*900000)})) }
  function save(){ const p = { id: uuidv4(), ...form, issueDate: new Date().toISOString().slice(0,10) }; setPeople([p, ...people]); setForm({ familyName: '', givenName: '', dob: '', birthplace: '', passportNumber: '', photo: null }) }

  async function exportPDF(person){
    // if person provided, render a simple passport for them, else current form
    const node = previewRef.current
    const canvas = await html2canvas(node, { scale: 3 })
    const img = canvas.toDataURL('image/png')
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'pt', format: [1260, 891] })
    pdf.addImage(img, 'PNG', 0, 0, 1260, 891)
    pdf.save((person?.familyName || 'passport') + '_' + (person?.passportNumber || form.passportNumber || 'XH000000') + '.pdf')
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-4 bg-slate-800 rounded-lg">
        <h2 className="text-2xl font-bold mb-2">Создать паспорт</h2>
        <input name="familyName" value={form.familyName} onChange={handle} placeholder="Фамилия" className="p-2 rounded bg-slate-700/30 w-full mb-2" />
        <input name="givenName" value={form.givenName} onChange={handle} placeholder="Имя" className="p-2 rounded bg-slate-700/30 w-full mb-2" />
        <input name="dob" value={form.dob} onChange={handle} type="date" className="p-2 rounded bg-slate-700/30 w-full mb-2" />
        <input name="birthplace" value={form.birthplace} onChange={handle} placeholder="Место рождения" className="p-2 rounded bg-slate-700/30 w-full mb-2" />
        <div className="flex gap-2 mb-2">
          <input name="passportNumber" value={form.passportNumber} onChange={handle} placeholder="Номер" className="p-2 rounded bg-slate-700/30 flex-1" />
          <button onClick={gen} className="px-3 py-2 bg-emerald-600 rounded">Сгенерировать</button>
        </div>
        <label className="block p-2 bg-slate-700/20 rounded">Фото: <input type="file" accept="image/*" onChange={upload} /></label>
        <div className="mt-3"><button onClick={save} className="px-4 py-2 bg-indigo-600 rounded">Сохранить в реестр</button></div>
      </div>

      <div className="p-4 bg-slate-800 rounded-lg">
        <h3 className="text-2xl font-bold">Превью и экспорт</h3>
        <div ref={previewRef} className="p-4 bg-white text-slate-900 rounded-lg" style={{minHeight:360}}>
          <div className="flex gap-4">
            <div style={{width:160,height:200,background:'#f3f4f6',display:'flex',alignItems:'center',justifyContent:'center'}}>
              {form.photo ? <img src={form.photo} alt="photo" style={{width:'100%',height:'100%',objectFit:'cover'}} /> : <div className="text-slate-500">Фото</div>}
            </div>
            <div>
              <div className="text-xl font-bold">{form.familyName || 'Фамилия'} {form.givenName || ''}</div>
              <div>Номер: <span className="font-mono">{form.passportNumber || '—'}</span></div>
              <div>Дата рождения: {form.dob || '—'}</div>
              <div>Место рождения: {form.birthplace || '—'}</div>
            </div>
          </div>
        </div>
        <div className="mt-3 flex gap-2">
          <button onClick={()=>exportPDF()} className="px-4 py-2 bg-emerald-600 rounded">Экспорт текущего</button>
          {people[0] && <button onClick={()=>exportPDF(people[0])} className="px-4 py-2 bg-indigo-600 rounded">Экспорт первого в реестре</button>}
        </div>
      </div>

      <div className="md:col-span-2 p-4 bg-slate-800 rounded-lg">
        <h3 className="text-xl font-semibold">Реестр граждан</h3>
        {people.length === 0 ? <div className="text-slate-400 mt-2">Реестр пуст.</div> : (
          <div className="mt-3 space-y-2">
            {people.map(p => (
              <div key={p.id} className="p-2 bg-slate-700/30 rounded flex justify-between items-center">
                <div>
                  <div className="font-semibold">{p.familyName} {p.givenName}</div>
                  <div className="text-sm text-slate-400">{p.passportNumber} • {p.issueDate}</div>
                </div>
                <div className="flex gap-2">
                  <button onClick={()=>exportPDF(p)} className="px-3 py-1 bg-indigo-600 rounded">PDF</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
