import React, { useState } from 'react'
import useLocalState from '../../utils/useLocalState'

export default function EconomyModule(){
  const [currency, setCurrency] = useLocalState('x:currency', { name:'XHC', rateToUSD:0.25 })
  const [amount, setAmount] = useState(1)
  const stats = { gdp:34000000, population:1200000 }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-4 bg-slate-800 rounded-lg">
        <h2 className="text-2xl font-bold">Экономика</h2>
        <div className="mt-2 text-slate-300">Валюта: <b>{currency.name}</b> — курс к USD: {currency.rateToUSD}</div>
        <div className="mt-4 text-slate-300">ВВП: {stats.gdp.toLocaleString()} • Население: {stats.population.toLocaleString()}</div>
      </div>
      <div className="p-4 bg-slate-800 rounded-lg">
        <h3 className="text-xl font-semibold">Конвертер</h3>
        <input type="number" value={amount} onChange={e=>setAmount(Number(e.target.value))} className="p-2 rounded bg-slate-700/30 w-full" />
        <div className="mt-2 text-slate-300">{amount} {currency.name} ≈ {(amount * currency.rateToUSD).toFixed(2)} USD</div>
      </div>
    </div>
  )
}
