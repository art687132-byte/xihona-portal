import React from 'react'
import useLocalState from '../../utils/useLocalState'
import { v4 as uuidv4 } from 'uuid'

export default function CultureModule(){
  const [events, setEvents] = useLocalState('x:culture:events', [{id:1,date:'01-11',title:'День Хихоны',descr:'Праздник основания'}])
  const [gallery, setGallery] = useLocalState('x:culture:gallery', [])

  function upload(e){
    const f = e.target.files?.[0]; if(!f) return; const r=new FileReader(); r.onload=ev=>setGallery([{id:uuidv4(),src:ev.target.result,title:f.name}, ...gallery]); r.readAsDataURL(f)
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-4 bg-slate-800 rounded-lg">
        <h2 className="text-2xl font-bold">Культура</h2>
        <p className="text-slate-400">Праздники и события</p>
        <ul className="list-disc pl-6 mt-3 text-slate-300">
          {events.map(ev=> <li key={ev.id}><b>{ev.date}</b> — {ev.title} <span className="text-slate-400">{ev.descr}</span></li>)}
        </ul>
      </div>

      <div className="p-4 bg-slate-800 rounded-lg">
        <h3 className="text-xl font-semibold">Галерея</h3>
        <label className="block p-2 bg-slate-700/20 rounded mt-2">Добавить <input type="file" accept="image/*" onChange={upload} /></label>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {gallery.map(g=> <div key={g.id} className="bg-white rounded overflow-hidden"><img src={g.src} alt={g.title} style={{width:'100%',height:120,objectFit:'cover'}}/></div>)}
        </div>
      </div>
    </div>
  )
}
