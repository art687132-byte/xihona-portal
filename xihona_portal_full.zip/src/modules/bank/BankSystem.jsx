import React, { useState } from 'react'
import useLocalState from '../../utils/useLocalState'
import { v4 as uuidv4 } from 'uuid'

export default function BankSystem(){
  const [accounts, setAccounts] = useLocalState('x:accounts', [])
  const [name, setName] = useState('')
  const [balance, setBalance] = useState(0)

  function create(){
    const acc = { id: uuidv4(), name: name || 'Без имени', number: 'AC'+Math.floor(100000+Math.random()*900000), balance: Number(balance) }
    setAccounts([acc, ...accounts]); setName(''); setBalance(0)
  }

  function transfer(fromId, toId, amount){
    amount = Number(amount)
    if(!fromId || !toId || amount <= 0) return alert('Неверные данные')
    const a = accounts.find(x=>x.id===fromId); const b = accounts.find(x=>x.id===toId)
    if(!a || !b) return alert('Счёт не найден')
    if(a.balance < amount) return alert('Недостаточно средств')
    setAccounts(accounts.map(x=> x.id===fromId?{...x, balance: x.balance-amount} : x.id===toId?{...x, balance: x.balance+amount} : x))
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-4 bg-slate-800 rounded-lg">
        <h2 className="text-2xl font-bold">Открыть счёт</h2>
        <input placeholder="Имя владельца" value={name} onChange={e=>setName(e.target.value)} className="p-2 rounded bg-slate-700/30 w-full mb-2" />
        <input type="number" placeholder="Начальный баланс" value={balance} onChange={e=>setBalance(e.target.value)} className="p-2 rounded bg-slate-700/30 w-full mb-2" />
        <button onClick={create} className="px-4 py-2 bg-emerald-600 rounded">Открыть</button>
      </div>

      <div className="p-4 bg-slate-800 rounded-lg">
        <h3 className="text-xl font-semibold">Счета</h3>
        {accounts.length===0 ? <div className="text-slate-400 mt-2">Нет счетов</div> : (
          <div className="mt-3 space-y-2">
            {accounts.map(a => (
              <div key={a.id} className="p-2 bg-slate-700/30 rounded flex justify-between items-center">
                <div><div className="font-semibold">{a.name}</div><div className="text-sm text-slate-400">{a.number}</div></div>
                <div className="font-mono">{a.balance.toFixed(2)}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <TransferPanel accounts={accounts} onTransfer={transfer} />
    </div>
  )
}

function TransferPanel({ accounts, onTransfer }){
  const [from, setFrom] = useState(''); const [to, setTo] = useState(''); const [amount, setAmount] = useState(0)
  function submit(){ onTransfer(from, to, amount); setAmount(0) }
  return (
    <div className="md:col-span-2 p-4 bg-slate-800 rounded-lg">
      <h3 className="text-xl font-semibold">Перевод</h3>
      <div className="grid md:grid-cols-3 gap-2 mt-3">
        <select value={from} onChange={e=>setFrom(e.target.value)} className="p-2 rounded bg-slate-700/30">
          <option value="">От (счёт)</option>
          {accounts.map(a=> <option key={a.id} value={a.id}>{a.name} — {a.number} ({a.balance.toFixed(2)})</option>)}
        </select>
        <select value={to} onChange={e=>setTo(e.target.value)} className="p-2 rounded bg-slate-700/30">
          <option value="">Кому (счёт)</option>
          {accounts.map(a=> <option key={a.id} value={a.id}>{a.name} — {a.number} ({a.balance.toFixed(2)})</option>)}
        </select>
        <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} className="p-2 rounded bg-slate-700/30" placeholder="Сумма" />
      </div>
      <div className="mt-3"><button onClick={submit} className="px-4 py-2 bg-indigo-600 rounded">Перевести</button></div>
    </div>
  )
}
