import React, { useState } from 'react'
import useLocalState from '../../utils/useLocalState'
import { v4 as uuidv4 } from 'uuid'

export default function ServicesModule(){
  const [requests, setRequests] = useLocalState('x:services', [])
  const [form, setForm] = useState({ type: 'справка', title: '', details: '' })

  function submit(){ const r={id:uuidv4(),status:'Новая',created:new Date().toISOString(),...form}; setRequests([r, ...requests]); setForm({type:'справка',title:'',details:''}) }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-4 bg-slate-800 rounded-lg">
        <h2 className="text-2xl font-bold">Госуслуги</h2>
        <select value={form.type} onChange={e=>setForm({...form, type:e.target.value})} className="p-2 rounded bg-slate-700/30 w-full">
          <option value="справка">Справка</option>
          <option value="регистрация">Регистрация адреса</option>
          <option value="паспорт">Паспорт</option>
        </select>
        <input placeholder="Краткое название" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} className="p-2 rounded bg-slate-700/30 w-full mt-2" />
        <textarea placeholder="Детали" value={form.details} onChange={e=>setForm({...form, details:e.target.value})} className="p-2 rounded bg-slate-700/30 w-full mt-2" rows={4} />
        <div className="mt-2"><button onClick={submit} className="px-4 py-2 bg-indigo-600 rounded">Отправить</button></div>
      </div>
      <div className="p-4 bg-slate-800 rounded-lg">
        <h3 className="text-xl font-semibold">Мои заявки</h3>
        {requests.length===0 ? <div className="text-slate-400 mt-2">Пока нет</div> : requests.map(r=> (
          <div key={r.id} className="p-2 bg-slate-700/20 rounded mt-2"><div className="flex justify-between"><b>{r.title}</b><div className="text-sm">{r.status}</div></div><div className="text-sm text-slate-400">{r.details}</div></div>
        ))}
      </div>
    </div>
  )
}
