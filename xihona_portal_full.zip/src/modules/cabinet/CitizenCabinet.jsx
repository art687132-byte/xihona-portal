import React from 'react'
import useLocalState from '../../utils/useLocalState'
import { v4 as uuidv4 } from 'uuid'

export default function CitizenCabinet(){
  const [profile, setProfile] = useLocalState('x:profile', { name:'', id: uuidv4(), notifications: [] })

  function addNote(){ const n={id:uuidv4(),text:'Уведомление',date:new Date().toISOString()}; setProfile({...profile, notifications:[n,...profile.notifications]}) }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-4 bg-slate-800 rounded-lg">
        <h2 className="text-2xl font-bold">Личный кабинет</h2>
        <div className="mt-2">ID: <span className="font-mono">{profile.id}</span></div>
        <input value={profile.name} onChange={e=>setProfile({...profile, name:e.target.value})} placeholder="Ваше имя" className="p-2 rounded bg-slate-700/30 w-full mt-2" />
        <div className="mt-3"><button onClick={addNote} className="px-4 py-2 bg-emerald-600 rounded">Добавить уведомление</button></div>
      </div>

      <div className="p-4 bg-slate-800 rounded-lg">
        <h3 className="text-xl font-semibold">Уведомления</h3>
        {profile.notifications.length===0 ? <div className="text-slate-400 mt-2">Нет уведомлений</div> : profile.notifications.map(n=> <div key={n.id} className="p-2 bg-slate-700/20 rounded mt-2"><div className="text-sm">{n.text}</div><div className="text-xs text-slate-500">{n.date}</div></div>)}
      </div>
    </div>
  )
}
