const express = require('express')
const cors = require('cors')
const jwt = require('jsonwebtoken')
const http = require('http')
const { Server } = require('socket.io')

const app = express()
app.use(cors())
app.use(express.json())

const SECRET = process.env.SECRET || 'xihona_dev_secret'
const users = [{ id: 'user1', username: 'citizen', password: 'password' }]

app.post('/api/login', (req, res) => {
  const { username, password } = req.body
  const user = users.find(u=>u.username===username && u.password===password)
  if(!user) return res.status(401).json({error:'invalid'})
  const token = jwt.sign({ id: user.id, username: user.username }, SECRET, { expiresIn: '2h' })
  res.json({ token })
})

app.get('/api/profile', (req,res)=>{
  const auth = req.headers.authorization
  if(!auth) return res.status(401).end()
  try{ const payload = jwt.verify(auth.replace('Bearer ', ''), SECRET); res.json({ id: payload.id, username: payload.username }) }catch(e){ res.status(401).end() }
})

const server = http.createServer(app)
const io = new Server(server, { cors: { origin: '*' } })
io.on('connection', socket => {
  socket.on('join', (room) => socket.join(room))
  socket.on('message', (msg) => io.emit('message', msg))
})

server.listen(4000, ()=>console.log('Dev server running on 4000'))
